//
//  ViewController.m
//  JCSignature
//
//  Created by 姜聪 on 2017/7/13.
//  Copyright © 2017年 姜聪. All rights reserved.
//

#import "ViewController.h"
@interface ViewController ()

@end

@implementation ViewController
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    signatureView= [[JCSignatureView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 300)];
    [self.view addSubview:signatureView];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"JCSignature";
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *getImgBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    getImgBtn.frame=CGRectMake(10, self.view.bounds.size.height-40, self.view.bounds.size.width/2-20, 30);
    [getImgBtn.layer setMasksToBounds:YES];//设置按钮的圆角半径不会被遮挡
    [getImgBtn.layer setCornerRadius:10];
    [getImgBtn.layer setBorderWidth:2];//设置边界的宽度
    [getImgBtn setTitle:@"保存签名" forState:UIControlStateNormal];
    [getImgBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [getImgBtn.titleLabel setFont:[UIFont systemFontOfSize:16.0]];
    [getImgBtn addTarget:self  action:@selector(getImgBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:getImgBtn];
    
    UIButton *clearImgBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    clearImgBtn.frame=CGRectMake(self.view.bounds.size.width/2+10, self.view.bounds.size.height-40, self.view.bounds.size.width/2-20, 30);
    [clearImgBtn.layer setMasksToBounds:YES];//设置按钮的圆角半径不会被遮挡
    [clearImgBtn.layer setCornerRadius:10];
    [clearImgBtn.layer setBorderWidth:2];//设置边界的宽度
    [clearImgBtn setTitle:@"重新签名" forState:UIControlStateNormal];
    [clearImgBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [clearImgBtn.titleLabel setFont:[UIFont systemFontOfSize:16.0]];
    [clearImgBtn addTarget:self  action:@selector(clearImgBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:clearImgBtn];
    
    // Do any additional setup after loading the view, typically from a nib.
}

//
-(void)getImgBtnClicked{
    [signatureView saveSignature];
    [signatureView clearSignature];
}

-(void)clearImgBtnClicked{
    [signatureView clearSignature];
}
@end
