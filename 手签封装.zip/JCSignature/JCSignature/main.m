//
//  main.m
//  JCSignature
//
//  Created by 姜聪 on 2017/7/13.
//  Copyright © 2017年 姜聪. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
