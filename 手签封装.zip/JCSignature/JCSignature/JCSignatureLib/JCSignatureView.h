//
//  JCSignatureView.h
//  JCSignature
//
//  Created by 姜聪 on 2017/7/13.
//  Copyright © 2017年 姜聪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCSignatureView : UIView{
    UILabel *lblSignature;
    CAShapeLayer *shapeLayer;
}
//获取图像
- (UIImage *)getSignatureImage;
//清除图像
- (void)clearSignature;
//保存图像到相册
- (void)saveSignature;
@end
